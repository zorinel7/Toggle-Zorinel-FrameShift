# Toggle – Zorinel / FrameShift Fork

## v1.10.3 – FrameShift localization

- Added automatic localization for the theme using Playnite language resource files.
- Fixed hard-coded Polish labels such as **Graj**, **Zainstaluj**, **Postęp**, **Zablokowane** and game launch/install states.
- FrameShift integration remains unchanged.
- Visual design and existing theme behavior are unchanged.

# Toggle — Zorinel / FrameShift Fork

Fork of the original Toggle Fullscreen theme by Jono.

## Important

**FrameShift is required for the FPS button to appear in Game Details.**
The theme integrates the FrameShift custom element using:

`FrameShift_FrameShift`

Install the **FrameShift** Playnite extension before using this theme.

## Localization

The theme uses Playnite's selected language automatically. FrameShift strings are included for the 44 locales supplied for this build. Changing the language in Playnite changes the corresponding theme localization resources after the theme is reloaded/restarted as required by Playnite.

## Compatibility

- Playnite Fullscreen
- Toggle original appearance and behavior preserved
- FrameShift FPS button integrated into Game Details
- Theme version: 1.10.2

## Credits

Original theme: **Jono**

Fork / FrameShift integration: **Zorinel**
