# Toggle — Zorinel Fork

This fork keeps the original Toggle appearance and behavior.

Changes for FrameShift:
- Fullscreen GameDetails integrates the FrameShift custom element using `x:Name="FrameShift_FrameShift"`.
- The theme uses Playnite locale-specific `Localization/<locale>.xaml` resources.
- FrameShift-localized strings are included for all locales supplied for this build.

Original theme author: Jono
Fork/integration: Zorinel


## v1.10.3
FrameShift localization was extended to all locale files included with this fork; hard-coded Polish UI labels in the theme were replaced with Playnite localization resources.
